package java;

public class Product {
    public Object getNazwa() {
        return null;
    }

    public Object getCena() {
        return null;
    }

    public Object getIlosc() {
        return null;
    }
}
